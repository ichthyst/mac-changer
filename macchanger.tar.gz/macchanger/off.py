#!/usr/bin/env python

import subprocess

subprocess.call("sudo ifconfig eth0 down", shell=True)
subprocess.call("sudo macchanger eth0 -p", shell=True)
subprocess.call("sudo ifconfig eth0 up", shell=True)
